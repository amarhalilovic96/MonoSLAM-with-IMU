#include <iostream>

#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>

#include <sensor_msgs/image_encodings.h>

#include <sensor_msgs/Imu.h>
#include <sensor_msgs/Image.h>

#include <vSLAM.hpp>

#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>

#include "opencv2/imgproc/imgproc_c.h"

#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include <opencv2/opencv.hpp>
#include <opencv2/core.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/core/base.hpp>
#include <opencv2/core/cvstd.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/features2d.hpp>
#include <opencv2/xfeatures2d/nonfree.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/calib3d.hpp>
#include <opencv/cv.h>

#include <opencv2/flann.hpp>

#include <geometry_msgs/Pose.h>
#include <nav_msgs/Path.h>

#include <cmath>

#include <visualization_msgs/Marker.h>
#include <visualization_msgs/MarkerArray.h>


using namespace std;
using namespace cv;

cv::RNG rng(12345);


vSLAM::vSLAM() : kamera()  
{ 
	this->putanjaKamere.header.frame_id = "/world";
	this->putanjaKamere.header.stamp = ros::Time::now();

	float sigma_vv = 0.0004, sigma_ww = 0.0004;
	
	kernel_min_size = kamera.kernel_size;
	sigma_pixel = kamera.sigma_pixel;
	sigma_pixel_2 = sigma_pixel*sigma_pixel;
	sigma_size = kamera.sigma_size;
	windowsSize = kamera.window_size;

   	delta_T = 0.5;
	T_camera = kamera.T_camera;
	scale = kamera.scale;

    	vektorStanja = Eigen::VectorXf::Zero(14); vektorStanja(3) = 1;

    	Pn = Eigen::MatrixXf::Identity(6,6);
	Pn(0,0) = kamera.sigma_vx * kamera.sigma_vx;
	Pn(1,1) = kamera.sigma_vy * kamera.sigma_vy;
	Pn(2,2) = kamera.sigma_vz * kamera.sigma_vz;
	Pn(3,3) = kamera.sigma_wx * kamera.sigma_wx;
	Pn(4,4) = kamera.sigma_wy * kamera.sigma_wy;
	Pn(5,5) = kamera.sigma_wz * kamera.sigma_wz;


	Kovarijansa = 0.00000016 * Eigen::MatrixXf::Identity(14, 14);
	Kovarijansa(13,13) = 0.09;

	Kovarijansa.block<3,3>(7,7) = sigma_vv * sigma_vv * Eigen::MatrixXf::Identity(3,3);
	Kovarijansa.block<3,3>(10,10) = sigma_ww * sigma_ww * Eigen::MatrixXf::Identity(3,3);

    	nInitFeatures = kamera.nInitFeatures;
	
}
/*
// update parametara kamere
void vSLAM::updateCameraParameters(double v_x, double v_y, double v_z, double w_x, double w_y, double w_z, double razlika, Eigen::Vector4f orijentacija)
{
	
	// azuriranje pozicije kamere
	vektorStanja(0) += (v_x) * (razlika);
	vektorStanja(1) += (v_y) * (razlika);
	vektorStanja(2) += (v_z) * (razlika);
	// azuriranje vektora linijske brzine kamere
	vektorStanja(7) = v_x;
	vektorStanja(8) = v_y;
	vektorStanja(9) = v_z;
	// azuriranje ugaone brzine kamere
	vektorStanja(10) = w_x;
	vektorStanja(11) = w_y;
	vektorStanja(12) = w_z;
	std::cout << "Spaseni podaci: " <<" v_x = " << vektorStanja(7) << ", v_y = " << vektorStanja(8) << ", v_z = " << vektorStanja(9) << ", w_x = " << vektorStanja(10) << ", w_y = " << vektorStanja(11) << ", w_z = " << vektorStanja(12) << " delta_t = " << razlika << std::endl;
	// azuriranje kvaterniona orijentacije kamere
	vektorStanja.segment<4>(3) = vektorUKvaternion(vektorStanja.segment<3>(10) * razlika);
	// vektorStanja.segment<4>(3) = orijentacija;
	 
}
*/

/*geometry_msgs::Pose vSLAM::dobijPozicijuKameru() 
{
	geometry_msgs::Pose pose;
	pose.position.x = vektorStanja(0);
	pose.position.y = vektorStanja(1);
	pose.position.z = vektorStanja(2);
	pose.orientation.w = vektorStanja(3);
	pose.orientation.x = vektorStanja(4);
	pose.orientation.y = vektorStanja(5);
	pose.orientation.z = vektorStanja(6);
	return pose;
}*/

void vSLAM::updatePutanje() 
{
	geometry_msgs::PoseStamped pose;
	pose.pose.position.x = vektorStanja(0);
	pose.pose.position.y = vektorStanja(1);
	pose.pose.position.z = vektorStanja(2);
	pose.pose.orientation.w = vektorStanja(3);
	pose.pose.orientation.x = vektorStanja(4);
	pose.pose.orientation.y = vektorStanja(5);
	pose.pose.orientation.z = vektorStanja(6);
	this->putanjaKamere.poses.push_back(pose);
}


nav_msgs::Path vSLAM::dobijPutanjuKamere() 
{
	return this->putanjaKamere;
}

void vSLAM::predikcija(double v_x, double v_y, double v_z, double w_x, double w_y, double w_z, double delta_T, double max_a, double max_omega) 
{
    this->delta_T = delta_T;
    // linearizacija tranzicijske funkcije
    Fk = df_dx(vektorStanja.segment<13>(0), this->delta_T);
    const int n = Kovarijansa.cols();
    Eigen::MatrixXf Fk_t = Eigen::MatrixXf::Identity(n,n);
    Fk_t.block<13,13>(0,0) = Fk;
    
    // Propagacija vjerovatnoce
    Eigen::MatrixXf Qck;
    Qck = Fk.middleCols<6>(7) * Pn * Fk.middleCols<6>(7).transpose();
    Eigen::MatrixXf Qk = Eigen::MatrixXf::Zero(n,n);
    Qk.block<13,13>(0,0) = Qck;
    Kovarijansa = (Fk_t * Kovarijansa * Fk_t.transpose() + Qk).eval();

    // update vektora stanja kamere
    Eigen::Vector3f lin_v(v_x,v_y,v_z);
    Eigen::Vector3f ug_w(w_x,w_y,w_z);
    vektorStanja.segment<13>(0) = updateCameraParameters(vektorStanja.segment<13>(0), this->delta_T, lin_v, ug_w);
    // update matrice Pn	
    //Pn(0,0)=Pn(1,1)=Pn(2,2) = max_a * this->delta_T;
    //Pn(3,3)=Pn(4,4)=Pn(5,5) = max_omega;
}




void vSLAM::korekcija() 
{

    // Opservaciona funkcija
    // esktrakcija stanja kamere	
    Eigen::Vector3f r = vektorStanja.segment<3>(0);
    Eigen::Vector4f q = vektorStanja.segment<4>(3);
    Eigen::Vector3f v = vektorStanja.segment<3>(7);
    Eigen::Vector3f w = vektorStanja.segment<3>(10);
    Eigen::Vector4f h = vektorUKvaternion(w * delta_T);


    Eigen::Vector4f qc = komplementKvaterniona(q);
    Eigen::Matrix3f RotCW = kvaternionURotacionuMatricu(qc);


    Eigen::Matrix3f RotCW_blurring = kvaternionURotacionuMatricu(komplementKvaterniona(proizvodKvaterniona(q,vektorUKvaternion(w*T_camera*this->delta_T))));
    Eigen::Vector3f r_blurring = r + v*T_camera*this->delta_T;
    Eigen::Vector2f hi_out_blurred;


    Eigen::VectorXf hi_out;
    Eigen::MatrixXf Hik;
    
    int featurer_counter = 0;
    
    for (int i = 0; i < features.size(); i++) 
    {
	int pos = features[i].position_in_state;
        if (!features[i].isXYZ()) 
	{                           
            Hik = Eigen::MatrixXf::Zero(2, vektorStanja.rows());
            Eigen::VectorXf f = vektorStanja.segment<6>(pos);

            if (f(5) <= 0) 
	    {
            	ROS_ERROR("Znacajka %d u beskonacnosti: %f", i, f(5));
            	features[i].setRemove();
            	features[i].setIsInInnovation(false);
            	continue;
            }
            Eigen::MatrixXf J_hW_f;
            Eigen::Vector3f d = inverse2XYZ(f, r, J_hW_f); 
            Eigen::Vector3f hC = RotCW*d; 
            Eigen::MatrixXf J_h_hC; 
            hi_out = kamera.projectAndDistort(hC, J_h_hC); 
            bool flag = isInsideImage(hi_out, frame.size(), windowsSize) && hC(2) >= 0 && f(5) > 0;

	    features[i].setIsInInnovation(flag); 
            if (!flag) continue;

	    featurer_counter++; 
            Eigen::MatrixXf d_h_q = dRq_times_d_dq(qc,d) * d_qbar_q(); // 5.44 i 5.43
                        
            Hik.middleCols<3>(0) = -f(5) * J_h_hC * RotCW;// 5.41
            Hik.middleCols<4>(3) = J_h_hC * d_h_q; // 5.44
            Hik.middleCols<6>(pos) = J_h_hC * RotCW * J_hW_f; // 5.47b
            features[i].h = hi_out;
	    features[i].H = Hik;

	    // Zamagljivanje
	    hi_out_blurred = kamera.projectAndDistort(RotCW_blurring*inverse2XYZ(f,r_blurring, J_hW_f), J_h_hC);
	    features[i].blur(hi_out, hi_out_blurred,kernel_min_size );

        } 
	else 
	{                          
            Hik = Eigen::MatrixXf::Zero(2, vektorStanja.rows());
            Eigen::Vector3f y = vektorStanja.segment<3>(pos);

            Eigen::Vector3f d = y-r; // koodinate u C, r - pozicija kamere
            Eigen::Vector3f hC = RotCW * d;// koordinate u W
            Eigen::MatrixXf J_h_hC;
            hi_out = kamera.projectAndDistort(hC, J_h_hC);
            bool flag = isInsideImage(hi_out, frame.size(), windowsSize) && hC(2) >= 0;

	    features[i].setIsInInnovation(flag);
            if (!flag) continue;

	    featurer_counter++;
            Eigen::MatrixXf d_h_q = dRq_times_d_dq(qc,d) * d_qbar_q();

            Hik.middleCols<3>(0) = -J_h_hC*RotCW;
            Hik.middleCols<4>(3) = J_h_hC*d_h_q;
            Hik.middleCols<3>(pos) = J_h_hC*RotCW;
            features[i].h = hi_out;
	    features[i].H = Hik;


	   // Zamagljivanje
	   hi_out_blurred = kamera.projectAndDistort(RotCW_blurring*(y-r_blurring), J_h_hC);
	   features[i].blur(hi_out, hi_out_blurred,kernel_min_size);
        }
    }

    Eigen::VectorXf temp_h_out;
    Eigen::MatrixXf temp_Hk;

    for (int i = 0, j = 0; i < features.size(); i++) 
    {
	if (features[i].patchIsInInnovation()) 
	{
		temp_h_out = Concat(temp_h_out,features[i].h);
		temp_Hk = vConcat(temp_Hk, features[i].H);
		features[i].position_in_z = 2*j;
		j++;
	}
    }    
	
    h_out = temp_h_out; // innovation vector
    Hk = temp_Hk; 
    

    if (h_out.rows() > 0) 
    {
	Eigen::MatrixXf Rk = sigma_pixel_2*Eigen::MatrixXf::Identity(Hk.rows(), Hk.rows());
        Sk = (Hk * Kovarijansa * Hk.transpose() + Rk).eval();       
	this->nacrtajPredikciju();
    }

    this->updatePutanje();

    cv::Point2f locF;
    int matchedFeatures = 0;
    int searchedFeatures = 0;

    // mjerenje i feature matching	
    for (int i = 0; i < features.size(); i++) 
    {
        if (features[i].patchIsInInnovation()) 
	{
            features[i].findMatch(frame, Sk.block<2,2>(features[i].position_in_z, features[i].position_in_z), sigma_size, false);
            searchedFeatures++;
        }
    }

    // RANSAC
	int nhyp = 10000;
	float p = 0.99;
	float th = 2*sigma_pixel;
	
	srand(time(NULL));
	
	int num_zli = 0;
	
	std::vector<int> ransacindex;


	for (int i = 0; i < features.size(); i++) 
	{
		if (features[i].patchIsInInnovation())  ransacindex.push_back(i);
	}


	for (int i = 0; i < nhyp && ransacindex.size() > 0; i++)
	 {
		int actual_num_zli = 0;
		int posRansac = rand()%ransacindex.size();
		int selectPatch = ransacindex[posRansac];
		ransacindex.erase(ransacindex.begin() + posRansac);

		Eigen::MatrixXf S_i = features[selectPatch].H * Kovarijansa * features[selectPatch].H.transpose() + sigma_pixel_2 * Eigen::MatrixXf::Identity(features[selectPatch].H.rows(), features[selectPatch].H.rows());
        	Eigen::MatrixXf K_i = Kovarijansa*features[selectPatch].H.transpose()*S_i.inverse();
		Eigen::VectorXf vektorStanja_i = vektorStanja + K_i*(features[selectPatch].z - features[selectPatch].h);
		
		Eigen::Vector3f r = vektorStanja_i.segment<3>(0);
		Eigen::Vector4f q = vektorStanja_i.segment<4>(3)/vektorStanja_i.segment<4>(3).norm();
    		Eigen::Matrix3f RotCW = kvaternionURotacionuMatricu(komplementKvaterniona(q));	
		
    		int searched_features = 0;
		for (int i = 0; i < features.size(); i++) 
		{
			if (!features[i].patchIsInInnovation()) continue;
			Eigen::Vector2f hi_i;
			int pos = features[i].position_in_state;

			if (!features[i].isXYZ()) 
			{
				Eigen::VectorXf f = vektorStanja_i.segment<6>(pos);
				Eigen::Vector3f d = inverse2XYZ(f, r);
				hi_i = kamera.projectAndDistort(RotCW*d);
			} 
			else 
			{
	            		Eigen::Vector3f y = vektorStanja.segment<3>(pos);
	            		Eigen::Vector3f d = y-r;
	            		Eigen::Vector3f hC = RotCW*d;
	            		Eigen::MatrixXf J_hf_hC;
	            		hi_i = kamera.projectAndDistort(hC, J_hf_hC);
			}

			features[i].setIsInLi((features[i].z - hi_i).norm() <= th);
			if (features[i].patchIsInLi()) actual_num_zli++;
			searched_features++;

    		}
    	
    		if (actual_num_zli > num_zli) 
		{
	    		num_zli = actual_num_zli;
	    		nhyp = log(1-p)/(log(num_zli/(matchedFeatures+0.0f)));
	    		for (int i = 0; i < features.size(); i++) 
			{
	    			if (features[i].patchIsInInnovation()) features[i].ConfirmIsInLi();
	    		}
	    	}
	}
	

	Eigen::VectorXf z_li;
    	Eigen::MatrixXf H_li;
    	Eigen::VectorXf h_li;

	for (int i = 0, j = 0; i < features.size(); i++) 
	{
		if (features[i].patchIsInLi()) 
		{
			h_li = Concat(h_li,features[i].h);
			H_li = vConcat(H_li,features[i].H);
			z_li = Concat(z_li, features[i].z);
			features[i].position_in_z = 2*j;
			j++;
		}
	}    


	Eigen::MatrixXf Kovarijansa_tmp = Kovarijansa;
	Eigen::VectorXf vektorStanja_tmp = vektorStanja;

    	if (z_li.rows() > 0) 
	{
	    	int p = H_li.rows();
		Eigen::MatrixXf Rk = sigma_pixel_2 * Eigen::MatrixXf::Identity(p,p);	
    		Sk = H_li * Kovarijansa_tmp * H_li.transpose() + Rk;
    		Kk = Kovarijansa_tmp * H_li.transpose() * Sk.inverse();
    		vektorStanja_tmp = vektorStanja + Kk * (z_li - h_li);
    		Kovarijansa_tmp = ((MatrixXf::Identity(Kovarijansa_tmp.rows(),Kovarijansa_tmp.rows()) - Kk*H_li)*Kovarijansa_tmp);
       		normalizujKvaternion(vektorStanja_tmp,Kovarijansa_tmp);
    	} 
	else 
	{
        	ROS_ERROR("No low-innovation inlajera");
    	}
 

    th = 1;
    if (1) 
    {
		Eigen::Vector3f r = vektorStanja.segment<3>(0);
		Eigen::Vector4f q = vektorStanja.segment<4>(3);
		Eigen::Vector4f qc = komplementKvaterniona(q);
		Eigen::Matrix3f RotCW = kvaternionURotacionuMatricu(qc);
		Eigen::Matrix2f S_hi;
		Eigen::Vector2f hi_hi;

		int counter = 0;
		for (int i = 0; i < features.size(); i++) 
		{
			if (!features[i].patchIsInLi() && features[i].patchIsInInnovation()) 
			{
				int pos = features[i].position_in_state;
				if (!features[i].isXYZ()) 
				{
					Eigen::MatrixXf Hi_hi = MatrixXf::Zero(2, vektorStanja.rows());
					Eigen::VectorXf f = vektorStanja.segment<6>(pos);
					Eigen::MatrixXf J_hp_f;
					Eigen::Vector3f d = inverse2XYZ(f, r, J_hp_f);
					Eigen::MatrixXf J_hf_hi;
					features[i].h = kamera.projectAndDistort(RotCW*d, J_hf_hi);

		            		Eigen::MatrixXf d_h_q = dRq_times_d_dq(qc,d)*d_qbar_q();
		            		Hi_hi.middleCols<3>(0) = -f(5)*J_hf_hi*RotCW;
		            		Hi_hi.middleCols<4>(3) = J_hf_hi*d_h_q;
		            		Hi_hi.middleCols<6>(pos) = J_hf_hi*RotCW*J_hp_f;
					features[i].H = Hi_hi;


				} 
				else 
				{
					Eigen::MatrixXf Hi_hi = Eigen::MatrixXf::Zero(2, vektorStanja.rows());
		            		Eigen::Vector3f y = vektorStanja.segment<3>(pos);
		            		Eigen::Vector3f d = y-r;
		            		Eigen::Vector3f hC = RotCW*d;
		            		Eigen::MatrixXf J_hf_hC;
		            		features[i].h = kamera.projectAndDistort(hC, J_hf_hC);

		            		Eigen::MatrixXf d_h_q = dRq_times_d_dq(qc,d)*d_qbar_q();

		            		Hi_hi.middleCols<3>(0) = -J_hf_hC*RotCW;
		            		Hi_hi.middleCols<4>(3) = J_hf_hC*d_h_q;
		            		Hi_hi.middleCols<3>(pos) = J_hf_hC*RotCW;
					features[i].H = Hi_hi;
				}

				S_hi = features[i].H*Kovarijansa_tmp*features[i].H.transpose();
				features[i].setIsInHi((features[i].h - features[i].z).transpose()*S_hi.inverse()*(features[i].h - features[i].z) <= th);
				counter++;
			}
		}
    }


    	Eigen::VectorXf z_hi;
    	Eigen::MatrixXf H_hi;
    	Eigen::VectorXf h_hi;
	for (int i = 0, j = 0; i < features.size(); i++) 
	{
		if (features[i].patchIsInHi()) 
		{
			h_hi = Concat(h_hi,  features[i].h);
			H_hi = vConcat(H_hi, features[i].H);
			z_hi = Concat(z_hi,  features[i].z);
			features[i].position_in_z = 2*j;
			j++;
		}
	}    


	bool flag_correction = false;
	Eigen::Matrix3f corr_ass_sigma = 0.00001*Matrix3f::Identity();

	if (kamera.forsePlane) 
	{
		Eigen::Vector3f corr_ass = Eigen::Vector3f::Zero();
		Eigen::MatrixXf corr_ass_H = Eigen::MatrixXf::Zero(3,vektorStanja_tmp.size());
		corr_ass_H(0,1) = 1;
		corr_ass_H(1,4) = 1;
		corr_ass_H(2,6) = 1;

		Eigen::Vector3f h_corr_ass;
		h_corr_ass << vektorStanja_tmp(1), vektorStanja_tmp(4),  vektorStanja_tmp(6);
		h_hi = Concat(h_hi,  h_corr_ass);
		z_hi = Concat(z_hi,  corr_ass);
		H_hi = vConcat(H_hi, corr_ass_H);
		flag_correction = true;
	}




    if (z_hi.rows() > 0) 
    {
    	int p = H_hi.rows();
    	Sk = H_hi * Kovarijansa_tmp * H_hi.transpose();

    	Eigen::MatrixXf Sk_error = sigma_pixel_2*Eigen::MatrixXf::Identity(p,p);
    	if (flag_correction) Sk_error.block<3,3>(p-3,p-3) = corr_ass_sigma;

    	Sk += Sk_error;

    	Kk = Kovarijansa_tmp*H_hi.transpose()*Sk.inverse();
    	vektorStanja_tmp = vektorStanja_tmp + Kk*(z_hi - h_hi);
        Kovarijansa_tmp = ((Eigen::MatrixXf::Identity(Kovarijansa_tmp.rows(),Kovarijansa_tmp.rows()) - Kk*H_hi)*Kovarijansa_tmp).eval();
       	normalizujKvaternion(vektorStanja_tmp,Kovarijansa_tmp);
    }
    
    if (1) {
    	vektorStanja = vektorStanja_tmp;
    	Kovarijansa = Kovarijansa_tmp;
    }



    for (int i = 0; i < features.size(); i++) 
    {
    	features[i].drawUpdate(slikaSaZnacajkama, i);
    }

    
    for (int i = features.size()-1; i >= 0; --i)
    {
		features[i].update_quality_index();
		if (features[i].mustBeRemove()) this->removeFeature(i);
    }

    int nVisibleFeature = 0;
    for (int i = 0; i < features.size(); i++) if (features[i].patchIsInInnovation()) nVisibleFeature++;

    if (nVisibleFeature < kamera.min_features) 
    {
    	if (features.size() > kamera.max_features) this->removeFeature(0);
    	this->pronadjiZnacajke();
    }

    findFeaturesConvertible2XYZ();

    this->updatePutanje();
}




visualization_msgs::MarkerArray vSLAM::vratiKameru3D() 
{

	visualization_msgs::MarkerArray kamera;
	visualization_msgs::Marker kamera_marker;
	kamera_marker.header.frame_id = "/world";
	kamera_marker.header.stamp = ros::Time::now();
	kamera_marker.ns  = "camera_marker";
	kamera_marker.type = visualization_msgs::Marker::MESH_RESOURCE;
	kamera_marker.mesh_resource = "package://ms3/dodaci/kamera3D.dae";
    	kamera_marker.action = visualization_msgs::Marker::ADD;
    	kamera_marker.pose.orientation.w = 1.0;
	kamera_marker.id = 0;
    	kamera_marker.scale.x = 0.1;
    	kamera_marker.scale.y = 0.1;
	kamera_marker.scale.z = 0.1;
	kamera_marker.color.b = 1.0f;
    	kamera_marker.color.a = 1.0;
	kamera_marker.pose.position.x = vektorStanja(0);
	kamera_marker.pose.position.y = vektorStanja(1);
	kamera_marker.pose.position.z = vektorStanja(2);	
	kamera_marker.pose.orientation.w = vektorStanja(3);
	kamera_marker.pose.orientation.x = vektorStanja(4);
	kamera_marker.pose.orientation.y = vektorStanja(5);
	kamera_marker.pose.orientation.z = vektorStanja(6);
	kamera.markers.push_back(kamera_marker);

	return kamera;
}



visualization_msgs::MarkerArray vSLAM::vratiZnacajke3D() 
{
	
	visualization_msgs::Marker tacke;
	tacke.header.frame_id = "/world";
	tacke.header.stamp = ros::Time::now();
	tacke.ns  = "tacke_i_linije";
	tacke.action = visualization_msgs::Marker::ADD;
	tacke.pose.orientation.w = 1.0;
	tacke.id = 0;
	tacke.type = visualization_msgs::Marker::SPHERE_LIST;
	tacke.scale.x = 0.1;
	tacke.scale.y = 0.1;
	tacke.scale.z = 0.1;
	tacke.color.r = 0.0f;
	tacke.color.g = 0.0f;
	tacke.color.b = 0.0f;
	tacke.color.a = 1.0;


	visualization_msgs::MarkerArray points;

	for (int i = 0; i < this->features.size(); i++) 
	{
		int pos = this->features[i].position_in_state;
		Eigen::Vector3f d;

		if (!features[i].isXYZ()) 
		{
			Eigen::MatrixXf Jf;
			d = depth2XYZ(vektorStanja.segment<6>(pos), Jf);
			geometry_msgs::Point p;
			p.x = d(0);
			p.y = d(1);
			p.z = d(2);
			tacke.points.push_back(p);
			

		} 
		else 
		{
			d = vektorStanja.segment<3>(pos);
			geometry_msgs::Point p;
			p.x = d(0);
			p.y = d(1);
			p.z = d(2);
			tacke.points.push_back(p);

		}

    	}
	points.markers.push_back(tacke);

    return points;
}

void vSLAM::primiFrame(cv::Mat noviFrame) 
{
	stari_frame = frame.clone();
    	originalnaSlika = noviFrame.clone();
    	slikaSaZnacajkama = noviFrame.clone();
    	cvtColor(noviFrame, frame, CV_BGR2GRAY);
}


int vSLAM::addFeature(cv::Point2f pf) 
{
    if (pf.x > windowsSize/2 && pf.y > windowsSize/2 && pf.x < frame.size().width - windowsSize/2 && pf.y < frame.size().height - windowsSize/2) 
    {
    	int pos = vektorStanja.size();
        Feature newPat(cv::Mat(frame, cv::Rect(pf.x-windowsSize/2, pf.y-windowsSize/2, windowsSize,windowsSize)), pf, pos);
        features.push_back(newPat);

		
        Eigen::Vector2f hd;
        hd << (float)pf.x, (float)pf.y;
    
        Eigen::Vector3f r = vektorStanja.segment<3>(0);
        Eigen::Vector4f q = vektorStanja.segment<4>(3);
        
        Eigen::MatrixXf Jac_hCHd;
        Eigen::Vector3f hC = kamera.UndistortAndDeproject(hd, Jac_hCHd);
        
        Eigen::Matrix3f Rot = kvaternionURotacionuMatricu(q);

        Eigen::Vector3f hW = Rot*hC;

        float hx = hW(0);
        float hy = hW(1);
        float hz = hW(2);

        float ro = kamera.rho_0;


        float theta = std::atan2(hx,hz);
        float phi = std::atan2(-hy, sqrt(hx*hx+hz*hz));		

	// Update vektora stanja i matrice kovarijanse

	Eigen::VectorXf f(6);
	f << r, theta, phi, ro;
	vektorStanja = Concat(vektorStanja,f);


        int nOld = Kovarijansa.rows();
        Eigen::MatrixXf Js = Eigen::MatrixXf::Zero(nOld+6, nOld+3);
        Js.block(0,0,nOld,nOld) = Eigen::MatrixXf::Identity(nOld,nOld);
        Js.block<3,3>(nOld,0) = Eigen::MatrixXf::Identity(3,3);
		
		
        Eigen::MatrixXf Jf_hW = d_f_d_hW(hW);
        Eigen::MatrixXf J_hW_q = dRq_times_d_dq(q,hC);

        Js.block<6,4>(nOld,3) = Jf_hW*J_hW_q;
        Js.block<6,2>(nOld,nOld) = Jf_hW*Rot*Jac_hCHd;
        Js.block<6,1>(nOld, nOld+2) << 0,0,0,0,0,1;

        Eigen::MatrixXf S = sigma_pixel_2*Eigen::MatrixXf::Identity(nOld+3, nOld+3);
        S.block(0,0, nOld, nOld) = Kovarijansa;

        S(nOld + 2, nOld + 2) =  kamera.sigma_rho_0;

	Kovarijansa = Js*S*Js.transpose();
        return 1;
    }
    return 0;
}



void vSLAM::removeFeature(int index) 
{
    int pos = features[index].position_in_state;
    
    Feature p = features[index];

    int first = pos;
    
    int size = (p.isXYZ()?3:6);

    if (p.n_find > 5) 
    {
		if (p.isXYZ()) 
		{
			p.XYZ_pos = vektorStanja.segment<3>(pos);
		} 
		else 
		{
			Eigen::MatrixXf J;
			p.XYZ_pos = depth2XYZ(vektorStanja.segment<6>(pos), J);
		}
	    obrisane_features.push_back(p);
    }


    int dim = Kovarijansa.cols();

    int last = vektorStanja.rows() - pos - size;

    if (index != features.size() - 1) 
    {
        vektorStanja = Concat(vektorStanja.head(first), vektorStanja.tail(last));
        Kovarijansa = vConcat(Kovarijansa.topRows(first), Kovarijansa.bottomRows(last));
        Kovarijansa = hConcat(Kovarijansa.leftCols(first), Kovarijansa.rightCols(last));
    } 
    else 
    {
        vektorStanja = vektorStanja.head(pos).eval();
        Kovarijansa = Kovarijansa.block(0,0,pos,pos).eval();
    }

    for(int i = index + 1; i < features.size(); i++) 
    {
    	features[i].change_position(-size);
    }

    features.erase(features.begin()+index);
}




Eigen::Vector3f vSLAM::depth2XYZ(Eigen::VectorXf f, Eigen::MatrixXf &J) 
{
    const float theta = f(3);
    const float phi = f(4);
    const float ro = f(5);
    Eigen::Vector3f m;
    m(0) = std::sin(theta)*std::cos(phi);
    m(1) = -std::sin(phi);
    m(2) = std::cos(theta)*std::cos(phi);

    Eigen::Vector3f y = f.segment<3>(0) + m/ro;

    J = Eigen::MatrixXf::Zero(3,6);
    J.middleCols<3>(0) = Eigen::Matrix3f::Identity();

    J(0,3) = std::cos(theta)*std::cos(phi)/ro;
    J(1,3) = 0;
    J(2,3) = -std::sin(theta)*std::cos(phi)/ro;

    J(0,4) = -std::sin(theta)*std::sin(phi)/ro;
    J(1,4) = -std::cos(phi)/ro;
    J(2,4) = -std::cos(theta)*std::sin(phi)/ro;

    J.col(5) = -m/(ro*ro);
    return y;

}


void vSLAM::convert2XYZ(int index) 
{
    int pos = features[index].position_in_state;
    int size = 6;
    int dx = 3;
    Eigen::VectorXf f = vektorStanja.segment<6>(pos);
    const float theta = f(3);
    const float phi = f(4);
    const float ro = f(5);
    Eigen::Vector3f m;
    m(0) = std::sin(theta)*std::cos(phi);
    m(1) = -std::sin(phi);
    m(2) = std::cos(theta)*std::cos(phi);

    Eigen::Vector3f y = f.segment<3>(0) + m/ro;

    Eigen::Vector3f d = y - vektorStanja.segment<3>(0);

    float sigma = Kovarijansa(pos+5,pos+5);

    float t = d.transpose()*m;

    float L = 4*sigma*std::abs(t)/(ro*ro*d.squaredNorm());
    if (L <= 0) 
    {
    	features[index].setRemove();
    }
    if (L < 0.01) 
    {
        Eigen::MatrixXf J_hp_f = Eigen::MatrixXf::Zero(3,6);
        J_hp_f.middleCols<3>(0) = Eigen::Matrix3f::Identity();


        J_hp_f(0,3) = std::cos(theta)*std::cos(phi)/ro;
        J_hp_f(1,3) = 0;
        J_hp_f(2,3) = -std::sin(theta)*std::cos(phi)/ro;

        J_hp_f(0,4) = -std::sin(theta)*std::sin(phi)/ro;
        J_hp_f(1,4) = -std::cos(phi)/ro;
        J_hp_f(2,4) = -std::cos(theta)*std::sin(phi)/ro;

        J_hp_f.col(5) = -m/(ro*ro);


        int first = pos;
        int last = vektorStanja.rows() - pos - 3;


        if (index != features.size() - 1) 
	{
            vektorStanja = Concat(vektorStanja.head(first), vektorStanja.tail(last));
            vektorStanja.segment<3>(pos) = y;
        } 
	else 
	{
            vektorStanja = Concat(vektorStanja.head(first), y);
        }

        int n = Kovarijansa.cols();
        Eigen::MatrixXf J = Eigen::MatrixXf::Zero(n-3,n);
        J.topLeftCorner(pos,pos) = Eigen::MatrixXf::Identity(pos,pos);
        J.block<3,6>(pos,pos) = J_hp_f;
        if (index != features.size() - 1) 
	{
        	J.bottomRightCorner(n-pos-6,n-pos-6) = Eigen::MatrixXf::Identity(n-pos-6,n-pos-6);
        }

        Kovarijansa = J * Kovarijansa * J.transpose();

        features[index].convertInXYZ();

        for(int i = index + 1; i < features.size(); i++) 
	{
        	features[i].change_position(-3);
        }
    }
}



void vSLAM::findFeaturesConvertible2XYZ() 
{
	for (int i = 0; i < features.size(); i++) 
	{
		if (!features[i].isXYZ()) convert2XYZ(i);
	}
}



void vSLAM::pronadjiZnacajke() 
{
    ROS_INFO("Traze se nove znacajke");

    int winSize = 2*windowsSize+1;
    cv::Mat maska = cv::Mat(frame.size(),CV_8UC1 );
    maska.setTo(cv::Scalar(0));
    int estrem = windowsSize;
    cv::Mat(maska, cv::Rect(estrem, estrem,maska.size().width-2*estrem, maska.size().height - 2*estrem)).setTo(cv::Scalar(255));

    for (int i = 0; i < features.size(); i++) {
    	if (features[i].center.x > windowsSize && 
    		features[i].center.y > windowsSize && 
    		features[i].center.x < maska.size().width - windowsSize && 
    		features[i].center.y < maska.size().height - windowsSize) 
    		{
    		int x = (features[i].center.x-winSize/2 > 0 ? 
    				features[i].center.x-winSize/2 : 0);
    		int y = (features[i].center.y-winSize/2 > 0 ? 
    				features[i].center.y-winSize/2 : 0);
    		int width = winSize - 
    			(features[i].center.x+winSize/2 <= frame.size().width ? 
    			0 : frame.size().width - features[i].center.x-winSize/2);
    		
			int height = winSize - 
    			(features[i].center.y+winSize/2 <= frame.size().height ? 
    			0 : frame.size().height - features[i].center.y-winSize/2);
    			
    		cv::Rect roi = cv::Rect(x,y, width, height);
    		cv::Mat(maska, roi).setTo(cv::Scalar(0));

    	}
    }

    // Implementacija sa Shi-Tomasi detektorom	
    std::vector<cv::Point2f> features;
    goodFeaturesToTrack(frame,features,1,0.01f,5,maska);
    for (int i = 0; i < features.size(); i++) {
	cv::Point2f novaZnacajka = cv::Point2f(features[i].x, features[i].y);
        this->addFeature(novaZnacajka);
    }
    ROS_INFO("Pronadjeno %d znacajki", features.size());	
    

    // Implementacija sa ORB-om
    /*std::vector<cv::KeyPoint> features;

    cv::Ptr<cv::FeatureDetector> detector = cv::ORB::create();
    detector->detect(frame, features);
    //cv::drawKeypoints(frame, features, frame, cv::Scalar::all(-1), cv::DrawMatchesFlags::DEFAULT);	
    for (int i = 0; i < features.size(); i++) {
	cv::Point2f novaZnacajka = cv::Point2f(features[i].pt.x, features[i].pt.y);
        this->addFeature(novaZnacajka);
    }*/
}



/*void vSLAM::nacrtajKorekciju(cv::Point f) 
{
    cv::rectangle(slikaSaZnacajkama, cv::Point(f.x - windowsSize/2, f.y - windowsSize/2), cv::Point(f.x + windowsSize/2, f.y + windowsSize/2), CV_RGB(0,0,255), 1);
    cv::circle(slikaSaZnacajkama, f, 2, CV_RGB(0,0,255),2);
	
}*/


void vSLAM::nacrtajPredikciju() 
{ 
    Eigen::MatrixXi sigma_mis = computeEllipsoidParameters(Sk, sigma_size);
    for (int i = 0; i < Sk.rows()/2; i++) 
    {
        cv::Point2i predictFeature(h_out(2*i), h_out(2*i+1));
        cv::ellipse(slikaSaZnacajkama, predictFeature, cv::Size(sigma_mis(i,0),sigma_mis(i,1)), (double)sigma_mis(i,2), 0, 360, CV_RGB(32, 32, 255));
    }

}

cv::Mat vSLAM::vratiSlikuSaZnacajkama() 
{
    return slikaSaZnacajkama.clone();
}


Eigen::MatrixXi computeEllipsoidParameters(Eigen::MatrixXf St, int sigma_size) 
{
    int nFeatures = St.cols()/2;
    Eigen::MatrixXi sigma_mis(nFeatures,3);
    for (int i = 0; i < nFeatures; i++) 
    {
        Eigen::SelfAdjointEigenSolver<Eigen::MatrixXf> eigenSolver(St.block<2,2>(2*i,2*i));
        Eigen::Vector2f eigs = eigenSolver.eigenvalues();
        Eigen::Matrix2f vecs = eigenSolver.eigenvectors();
 
        sigma_mis(i,0) = (eigs(0) > 0 ? (int)sigma_size*sqrt((double)eigs(0)) : 1);
        sigma_mis(i,1) = (eigs(1) > 0 ? (int)sigma_size*sqrt((double)eigs(1)) : 1);
        sigma_mis(i,2) = (int)(180/3.14*atan2((double)vecs(1,0), (double)vecs(0,0)));
    }
    return sigma_mis;
}



bool isInsideImage(Eigen::Vector2f hi, cv::Size size, int windowsSize) 
{
    float i = hi(0);
    float j = hi(1);
    
    if (i > windowsSize/2 && j > windowsSize/2 && i < size.width - windowsSize/2 && j < size.height - windowsSize/2) 
    {
        return true;
    }
    return false;

}





















