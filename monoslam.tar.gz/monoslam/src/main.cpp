#include <ros/ros.h>
#include <image_transport/image_transport.h>
#include <cv_bridge/cv_bridge.h>

#include <sensor_msgs/image_encodings.h>

#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>

#include <sensor_msgs/Imu.h>
#include <sensor_msgs/Image.h>

#include <vSLAM.hpp>

#include <geometry_msgs/Pose.h>
#include <nav_msgs/Path.h>



class MonoSLAM
{
    
	ros::NodeHandle nh;
        
	image_transport::ImageTransport it;
        image_transport::Subscriber image_subscriber;
	image_transport::Publisher image_publisher;

        ros::Subscriber imu_subscriber;
	ros::Subscriber	imu_pose_subscriber;

	ros::Publisher camera_pose_publisher;
	ros::Publisher camera_path_publisher;
	ros::Publisher features3D_publisher;
  	ros::Publisher camera3D_publisher;

	

   private:	
        vSLAM vslam;
	bool prvi;
        double v_x, v_y, v_z, w_x, w_y, w_z, a_x_prosla, a_z_prosla, a_y_prosla;
        double prosli_IMU, trenutni_IMU, max_a, max_omega;
	Eigen::Vector4f orijentacija;

    public:	 
    MonoSLAM(char *file = NULL) : it(nh),  vslam()
    {
	  ROS_INFO("test -1");
	  prvi = true;
          v_x = v_y = v_z = w_x = w_y = w_z = a_x_prosla = a_y_prosla = a_z_prosla = 0;
	  ROS_INFO("test 0");
	  prosli_IMU = trenutni_IMU =ros::Time::now().toSec();
	  ROS_INFO("test 1");
	  orijentacija << 1, 0, 0, 0;
	  max_a = 0;
	
	  image_publisher = it.advertise("/monoslam/slikaSaZnacajkama", 1);
          imu_subscriber = nh.subscribe("/multiwii/imu/data", 1, &MonoSLAM::imuCallback, this);
          image_subscriber = it.subscribe("/camera/image_raw", 1, &MonoSLAM::imageCallback, this);
	  //imu_pose_subscriber = nh.subscribe("multiwii/local_position/pose", 1, &MonoSLAM::imuPoseCallback, this);
	  //camera_pose_publisher = nh.advertise<geometry_msgs::Pose>("/monoslam/camera_pose", 1000);
	  camera_path_publisher = nh.advertise<nav_msgs::Path>("/monoslam/camera_path", 1000);
	  camera3D_publisher  = nh.advertise<visualization_msgs::MarkerArray>("/monoslam/camera3D", 1000);
	  features3D_publisher  = nh.advertise<visualization_msgs::MarkerArray>("/monoslam/features3D", 1000);	

    }


    ~MonoSLAM()
    {
    }


  /*void imuPoseCallback(const geometry_msgs::Pose::ConstPtr& p)
  {	
	  orijentacija =  Eigen::Vector4f(p->orientation.w, p->orientation.x, p->orientation.y, p->orientation.z);
  }*/

  void imuCallback(const sensor_msgs::Imu::ConstPtr& imu_msg)
  {
	  std::cout << "Primljeni IMU podaci" << std::endl;
	  prosli_IMU = trenutni_IMU;
	  trenutni_IMU = ros::Time::now().toSec();
	  const double a_x_trenutna = imu_msg->linear_acceleration.x / 1000;
	  const double a_y_trenutna = imu_msg->linear_acceleration.y / 1000;
	  const double a_z_trenutna = imu_msg->linear_acceleration.z / 1000;  
	  const double razlika = trenutni_IMU - prosli_IMU;
	  if(a_x_trenutna >= a_y_trenutna && a_x_trenutna >= a_z_trenutna)
	  {
		max_a = a_x_trenutna;
	  }
	  else if(a_y_trenutna >= a_x_trenutna && a_y_trenutna >= a_z_trenutna)
	  {
		max_a = a_y_trenutna; 
	  }
	  else  max_a = a_z_trenutna;	 
	  v_x += (a_x_trenutna) * (razlika);
	  v_y += (a_y_trenutna) * (razlika);
	  v_z += (a_z_trenutna) * (razlika);
	  double w_z_temp = imu_msg->angular_velocity.z - w_z;	
	  double w_y_temp = imu_msg->angular_velocity.y - w_y;
	  double w_x_temp = imu_msg->angular_velocity.x - w_x;
	  if(w_x_temp >= w_y_temp && w_x_temp >= w_z_temp)
	  {
		max_omega = w_x_temp;
	  }
	  else if(w_y_temp >= w_x_temp && w_y_temp >= w_z_temp)
	  {
		max_omega = w_y_temp;
	  }
	  else  max_omega = a_z_trenutna;
	  w_z = imu_msg->angular_velocity.z;  
	  w_y = imu_msg->angular_velocity.y; 
	  w_x = imu_msg->angular_velocity.x;
	  std::cout << "Poslani: v_x = " << v_x << ", v_y = " << v_y << ", v_z = " << v_z << ", w_x = " << w_x <<
	", w_y = " << w_y << ", w_z = " << w_z << std::endl;
	  std::cout << "razlika: " << razlika << std::endl;
	  //std::cout << "a_x = " << a_x_trenutna << ", a_y = " << a_y_trenutna << ", a_z = " << a_z_trenutna << std::endl;
	  //std::cout << "razlika: " << razlika << std::endl;
	  //vslam.updateCameraParameters(v_x, v_y, v_z, w_x, w_y, w_z, razlika, orijentacija);
	  
  }	


  void imageCallback(const sensor_msgs::ImageConstPtr& msg)
  {

    std::cout << "Primljen novi frame" << std::endl;
    cv_bridge::CvImagePtr cv_ptr;
    try
    {
      cv_ptr = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::BGR8);
    }
    catch (cv_bridge::Exception& e)
    {
      ROS_ERROR("cv_bridge exception: %s", e.what());
      return;
    }
    	  
    cv::Mat frame;

    if(prvi)
    {
	prvi = false;
	vslam.primiFrame(cv_ptr->image);
	vslam.pronadjiZnacajke();
	frame = vslam.vratiSlikuSaZnacajkama();
    }
    else
    {
	//vslam.primiFrame(cv_ptr->image, msg->header.stamp.toSec());
	vslam.primiFrame(cv_ptr->image);	

	//vslam.predikcija(v_x, v_y, v_z, w_x, w_y, w_z, trenutni_IMU - prosli_IMU, max_a, max_omega);
	vslam.predikcija(0, 0, 0, 0, 0, 0, trenutni_IMU - prosli_IMU, 0.01, 0.01);
	
	vslam.korekcija();

	camera_path_publisher.publish(vslam.dobijPutanjuKamere());

	//geometry_msgs::Pose kameraPose = vslam.dobijPozicijuKamere();
	//camera_pose_publisher.publish(vslam.dobijPozicijuKamere());

	features3D_publisher.publish(vslam.vratiZnacajke3D());
	camera3D_publisher.publish(vslam.vratiKameru3D());
		
	frame = vslam.vratiSlikuSaZnacajkama();
    }
	

    cv_ptr->image = frame;
    image_publisher.publish(cv_ptr->toImageMsg());
  }

};


int main(int argc, char** argv)
{
	ros::init(argc, argv, "MonoSLAM");
	char *file = NULL;
	if (argc > 1) file = argv[1];

	std::cout << "Prije" << std::endl;

  	MonoSLAM ms(file);
  
	std::cout << "Poslije" << std::endl;

	ros::spin();
  	return 0;
}


