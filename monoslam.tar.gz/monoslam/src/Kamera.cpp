#include <Kamera.hpp>
#include <iostream>

Kamera::Kamera()
{
	// podaci dobijeni kalibracijom kamere
	fx = 491.9125;
	fy = 485.2439;	
	u0 = 374.3649;
	v0 = 234.3357;
	k1 = -0.1487;
	k2 = 0.6132;
	k3 = -1.3144;
	p1 = 0.0233;
	p2 = 0.0135;

	sigma_vx  = sigma_vy = sigma_vz = 0.01f;
	sigma_wx  = sigma_wy = sigma_wz = 0.01f;

	window_size = 21;
	sigma_pixel = 2;

	rho_0 = 0.1f;
	sigma_rho_0 = 0.25f;
	
	scale = 1;

	T_camera = 0.05f;

	sigma_size = 2;

	nInitFeatures = 5;

	min_features = 30;
	max_features = 100;

	forsePlane = 0;
}


Eigen::Matrix2f Kamera::diff_distort_undistort(Eigen::Vector2f v) 
{
    const float r_2 = v(0) * v(0) + v(1) * v(1);
    const float l = 1 + k1 * r_2 + k2 * (r_2 * r_2) + k3 * (r_2 * r_2 * r_2);

    Eigen::Vector2f v_contr;
    v_contr << v(1), v(0);

    Eigen::Vector2f pv;
    pv << p1, p2;

    Eigen::Vector2f pv_contr;
    pv_contr << p2, p1;

    Eigen::Matrix2f j_matrix;
    j_matrix << p2 * v(0), 0, 0, p1 * v(1);

    const float f = k1 + 2 * k2 * r_2 + 3 * k3 * (r_2 * r_2);

    Eigen::Matrix2f Jacobian_Distort_Undistort = l * Eigen::Matrix2f::Identity() + 2 * f * v * v.transpose() + 2 * pv * v_contr.transpose() + 2 * pv_contr * v.transpose() + 4 * j_matrix;
    
    return Jacobian_Distort_Undistort;
}	




Eigen::Vector2f Kamera::projectAndDistort(Eigen::Vector3f v, Eigen::MatrixXf &J) 
{
    
    float x = v(0);
    float y = v(1);
    float z = v(2);

    float x1 = x/z;
    float y1 = y/z;
    
    Eigen::MatrixXf Jacobian_RetinaUnd_hC(2,3);
    Jacobian_RetinaUnd_hC << 1/z, 0, -x/(z*z), 0, 1/z, -y/(z*z);
    
    float r_2 = x1 * x1 + y1 * y1;
    float l = 1 + k1 * r_2 + k2 * (r_2 * r_2) + k3 * (r_2 * r_2 * r_2);

    
    float x2 = x1 * l + 2 * p1 * x1 * y1 + p2 * (r_2 + 2 * (x1 * x1));
    float y2 = y1 * l + 2 * p2 * x1 * y1 + p1 * (r_2 + 2 * (y1 * y1));

    Eigen::Vector2f hn;
    hn << x1, y1;
    
    Eigen::Vector2f hd;
    hd << fx * x2 + u0, fy * y2 + v0; 

    Eigen::MatrixXf Jacobian_Pixel_Retina(2,2);
    Jacobian_Pixel_Retina << fx, 0, 0, fy;
        
    J = Jacobian_Pixel_Retina * diff_distort_undistort(hn) * Jacobian_RetinaUnd_hC;
    
    return hd;
}



Eigen::Vector2f Kamera::projectAndDistort(Eigen::Vector3f v) 
{
 
    float x = v(0);
    float y = v(1);
    float z = v(2);

    float x1 = x/z;
    float y1 = y/z;

    float r_2 = x1 * x1 + y1 * y1;
    float l = 1 + k1 * r_2 + k2 * (r_2 * r_2) + k3 * (r_2 * r_2 * r_2);

    
    float x2 = x1 * l + 2 * p1 * x1 * y1 + p2 * (r_2 + 2 * (x1 * x1));
    float y2 = y1 * l + 2 * p2 * x1 * y1 + p1 * (r_2 + 2 * (y1 * y1));

    Eigen::Vector2f hd;
    hd << fx * x2 + u0, fy * y2 + v0;

    return hd;
}

Eigen::Vector3f Kamera::UndistortAndDeproject(Eigen::Vector2f v, Eigen::MatrixXf &J)
{
    float x2 = (v(0) - u0) / fx;
    float y2 = (v(1) - v0) / fy;

    Eigen::MatrixXf Jacobian_Retina_Pixel(2,2);
    Jacobian_Retina_Pixel << 1/fx, 0, 0, 1/fy;
    
    float x1(x2);
    float y1(y2);

    float r_2;
    float l;

    float dx,dy;

    int n_iter = 50;
    for (int i = 0; i < n_iter; ++i) 
    {
    	r_2 = (x1 * x1) + (y1 * y1);
    	l = 1 + k1 * r_2 + k2 * (r_2 * r_2) + k3 * (r_2 * r_2 * r_2);

        dx = 2 * p1 * x1 * y1 + p2 * (r_2 + 2 * (x1 * x1));
        dy = 2 * p2 * x1 * y1 + p1 * (r_2 + 2 * (y1 * y1));

        x1 = (x2 - dx)/l;
        y1 = (y2 - dy)/l;
    }
	
    Eigen::Vector2f hn;
    hn << x1,y1;
    
    Eigen::Vector3f hC;
    hC << x1, y1, 1;
    
    Eigen::MatrixXf Jacobian_hC_RetinaUnd(3,2);
    Jacobian_hC_RetinaUnd << 1, 0, 0, 1, 0, 0;
    
    J = Jacobian_hC_RetinaUnd * diff_distort_undistort(hn).inverse() * Jacobian_Retina_Pixel;

    return hC;
}


