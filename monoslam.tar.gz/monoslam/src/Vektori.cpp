#include <iostream>
#include <opencv2/opencv.hpp>
#include <Vektori.hpp>


Eigen::MatrixXf vConcat(Eigen::MatrixXf mat1, Eigen::MatrixXf mat2) 
{
	if (mat1.rows() == 0) return mat2;
	else 
	{
		Eigen::MatrixXf concatMatrix(mat1.rows() + mat2.rows(), mat1.cols());
		concatMatrix << mat1, mat2;
		return concatMatrix;
	}

}

Eigen::VectorXf Concat(Eigen::VectorXf mat1, Eigen::VectorXf mat2) 
{
	if (mat1.rows() == 0) return mat2;
	else 
	{
		Eigen::VectorXf concatMatrix(mat1.rows() + mat2.rows());
		concatMatrix << mat1, mat2;
		return concatMatrix;
	}

}

Eigen::MatrixXf hConcat(Eigen::MatrixXf mat1, Eigen::MatrixXf mat2) 
{
	if (mat1.cols() == 0) return mat2;
	else 
	{
		Eigen::MatrixXf concatMatrix(mat1.rows(), mat1.cols() + mat2.cols());
		concatMatrix << mat1, mat2;
		return concatMatrix;
	}

}


Eigen::MatrixXf dRq_times_d_dq(Eigen::Vector4f q, Eigen::Vector3f d) 
{
    Eigen::MatrixXf diff_Rq_times_dq(3,4);
    for (int j = 0; j < 4; j++) 
    {
    	diff_Rq_times_dq.col(j) = diffQuat2rot(q,j)*d;
    }
    return diff_Rq_times_dq;
}


// return Jacobian d(g(x))/dx
Eigen::MatrixXf df_dx(Eigen::VectorXf vektorStanja, float dT) 
{
    Eigen::Vector3f r = vektorStanja.segment<3>(0);
    Eigen::Vector4f q = vektorStanja.segment<4>(3);
    Eigen::Vector3f v = vektorStanja.segment<3>(7);
    Eigen::Vector3f w = vektorStanja.segment<3>(10);
    Eigen::Vector4f h = vektorUKvaternion(dT*w); 

    Eigen::MatrixXf Ft;
    Ft = Eigen::MatrixXf::Identity(13,13);
    Ft.block<4,4>(3,3) = Jacobian_qt_qt1(h);
    Ft.block<4,3>(3,10) = Jacobian_qt_w(q,w,dT);
    Ft.block<3,3>(0,7) = dT*Eigen::MatrixXf::Identity(3,3);

    return Ft;
}



// compute the Jacobian between q(t) and q(t-1) knowing the rotation h = quat(w*T)
Eigen::Matrix4f Jacobian_qt_qt1(Eigen::Vector4f h) 
{
    return kvaternionJacobianKomplementarni(h);    
}


// compute the Jacobian between q(t) and w(t-1) knowing the actual rotation q, w and dT
Eigen::MatrixXf Jacobian_qt_w(Eigen::Vector4f kvat, Eigen::Vector3f w, float dT) 
{    
    const float n = w.norm(); // ugao
    const float sinus = sin(dT*n/2);
    const float kosinus = cos(dT*n/2);
    const float Sinc = (n == 0 ? 1: 2*sin(dT*n/2)/(dT*n));
    
    Eigen::Vector3f n_w;
    if (n > 0) n_w = w/n;
    
    Eigen::Matrix4f t1;

    t1 = kvaternionJacobian(kvat);
    
    Eigen::MatrixXf t2 = Eigen::MatrixXf::Zero(4,3);
    t2.row(0) = -dT * 0.5 * sinus * n_w.transpose();
    t2.middleRows<3>(1) = dT*0.5*(Sinc * Eigen::Matrix3f::Identity() + (kosinus-Sinc) * n_w * n_w.transpose());

    Eigen::MatrixXf ret;
    ret = t1*t2;
    return ret;
}

Eigen::Matrix3f diffQuat2rot(Eigen::Vector4f kvat, int indeks) 
{
    Eigen::Matrix3f dR;

    if (indeks == 0) 
    {
        dR << 	 kvat(0), -kvat(3),  kvat(2),
         	 kvat(3),  kvat(0), -kvat(1),
        	-kvat(2),  kvat(1),  kvat(0);
        
    } 
    else if (indeks == 1) 
    {
        dR << 	kvat(1),  kvat(2),  kvat(3),
        	kvat(2), -kvat(1), -kvat(0),
        	kvat(3),  kvat(0), -kvat(1);

    } 
    else if (indeks == 2) 
    {
        dR <<	-kvat(2), kvat(1),  kvat(0),
        	 kvat(1), kvat(2),  kvat(3),
        	-kvat(0), kvat(3), -kvat(2);

    } 
    else if (indeks == 3) 
    {
        dR <<  -kvat(3), -kvat(0), kvat(1),
        	kvat(0), -kvat(3), kvat(2),
        	kvat(1),  kvat(2), kvat(3);
    }
    return 2 * dR;
}


Eigen::Vector4f komplementKvaterniona(Eigen::Vector4f kvat) 
{
    Eigen::Vector4f kvatC;
    kvatC << kvat(0), -kvat(1), -kvat(2), -kvat(3);
    return kvatC;
}

// update state-a kamere
Eigen::VectorXf updateCameraParameters(Eigen::VectorXf Xv, double dT, Eigen::Vector3f lin_v, Eigen::Vector3f ug_w) 
{
    Xv.segment<3>(7) = lin_v;
    Xv.segment<3>(10) = ug_w;	

    Eigen::Vector3f v = Xv.segment<3>(7);
    Eigen::Vector3f w = Xv.segment<3>(10);

    Xv.segment<3>(0) += dT * v;
    Xv.segment<4>(3) = proizvodKvaterniona(Xv.segment<4>(3), vektorUKvaternion(dT*w));
    
    return Xv;
}

Eigen::Matrix4f d_qbar_q() 
{
    Eigen::Matrix4f J = -Eigen::Matrix4f::Identity();
    J(0,0) = 1;
    return J;
}


// Jacobian df/dhW
Eigen::MatrixXf d_f_d_hW(Eigen::Vector3f hW) 
{
    // d_Theta_d_hW
    Eigen::MatrixXf J_Theta_hW(1,3);
    float normal = hW(0) * hW(0) + hW(2) * hW(2);
    J_Theta_hW(0,0) = hW(2)/normal;
    J_Theta_hW(0,1) = 0;
    J_Theta_hW(0,2) = -hW(2)/normal;
    
    // d_Phi_d_hW
    float normal2 = hW(0)*hW(0) + hW(1)*hW(1) + hW(2)*hW(2);
    Eigen::MatrixXf J_Phi_hW(1,3);
    J_Phi_hW(0,0) = hW(0)*hW(1)/(std::sqrt(normal)*normal2);
    J_Phi_hW(0,1) = -std::sqrt(normal)/normal2;
    J_Phi_hW(0,2) = hW(2)*hW(1)/(std::sqrt(normal)*normal2);
    
    Eigen::MatrixXf J_f_hW = Eigen::MatrixXf::Zero(6,3);
    J_f_hW.row(3) = J_Theta_hW;
    J_f_hW.row(4) = J_Phi_hW;

    return J_f_hW;
}


void normalizujKvaternion(Eigen::VectorXf &vektorStanja, Eigen::MatrixXf &Kovarijansa) 
{
    Eigen::Vector4f kvat = vektorStanja.segment<4>(3);
    
    const float norma = kvat.norm();
    vektorStanja.segment<4>(3) = kvat/norma;

    Eigen::MatrixXf Q;
    Q = norma * norma * Eigen::Matrix4f::Identity() - kvat * kvat.transpose();
    
    Q = (Q*(1/(norma*norma*norma))).eval();

    Eigen::MatrixXf Qc = Eigen::MatrixXf::Identity(Kovarijansa.rows(), Kovarijansa.cols());
    Qc.block<4,4>(3,3) = Q;

    Kovarijansa = (Qc*Kovarijansa*Qc.transpose()).eval();
}


Eigen::Vector4f vektorUKvaternion(Eigen::Vector3f v) 
{
    float alpha = v.norm();
    
    if (alpha != 0) 
    {
        Eigen::Vector4f kvat;
        kvat(0) = std::cos(alpha/2);
        kvat.segment<3>(1) = v * std::sin(alpha/2)/alpha;
        return kvat;
    }
    else 
    {
        return jedinicniKvaternion();
    }
}

Eigen::Vector4f jedinicniKvaternion() 
{
    Eigen::Vector4f kvat;
    kvat << 1,0,0,0;
    return kvat;
}




Eigen::Matrix3f kvaternionURotacionuMatricu(Eigen::Vector4f kvat) 
{
    float qr = kvat(0);
    float qi = kvat(1);
    float qj = kvat(2);
    float qk = kvat(3);

    Eigen::Matrix3f Mat;

    Mat <<	 1-2*qj*qj-2*qk*qk, 2*qi*qj-2*qr*qk,	2*qr*qj+2*qi*qk,
		 2*qr*qk+2*qi*qj,   1-2*qi*qi-2*qk*qk,	2*qj*qk-2*qr*qi,
		 2*qi*qk-2*qr*qj,   2*qr*qi+2*qj*qk,	1-2*qi*qi-2*qj*qj;
/*
	Mat <<	 qr*qr + qi*qi - qj*qj - qk*qk, 		-2*qr*qk+2*qi*qj,					 2*qr*qj+2*qi*qk,
		 2*qr*qk+2*qi*qj,				 qr*qr - qi*qi + qj*qj - qk*qk,				-2*qr*qi+2*qj*qk,
		-2*qr*qj+2*qi*qk,				 2*qr*qi+2*qj*qk,					 qr*qr - qi*qi - qj*qj + qk*qk;*/
    return Mat;
}


Eigen::Matrix4f kvaternionJacobian(Eigen::Vector4f kvat) 
{
	Eigen::Matrix4f Jac;
	
	Jac <<  kvat(0), -kvat(1), -kvat(2), -kvat(3),
		kvat(1),  kvat(0), -kvat(3),  kvat(2),
		kvat(2),  kvat(3),  kvat(0), -kvat(1),
		kvat(3), -kvat(2),  kvat(1),  kvat(0);
	
	return Jac;		
}


Eigen::Matrix4f kvaternionJacobianKomplementarni(Eigen::Vector4f kvat) 
{
	Eigen::Matrix4f Jac;

	Jac <<  kvat(0), -kvat(1), -kvat(2), -kvat(3),
		kvat(1),  kvat(0),  kvat(3), -kvat(2),
		kvat(2), -kvat(3),  kvat(0),  kvat(1),
		kvat(3),  kvat(2), -kvat(1),  kvat(0);

	return Jac;
		
}

Eigen::Vector4f proizvodKvaterniona(Eigen::Vector4f kvat1, Eigen::Vector4f kvat2) 
{
    Eigen::Vector4f kvat;
    
    kvat(0) = kvat1(0) * kvat2(0) - kvat1(1) * kvat2(1) - kvat1(2) * kvat2(2) - kvat1(3) * kvat2(3);
    kvat(1) = kvat1(1) * kvat2(0) + kvat1(0) * kvat2(1) + kvat1(2) * kvat2(3) - kvat1(3) * kvat2(2);
    kvat(2) = kvat1(0) * kvat2(2) - kvat1(1) * kvat2(3) + kvat1(2) * kvat2(0) + kvat1(3) * kvat2(1);
    kvat(3) = kvat1(0) * kvat2(3) + kvat1(1) * kvat2(2) - kvat1(2) * kvat2(1) + kvat1(3) * kvat2(0);

    return kvat;
}



Eigen::Vector3f inverse2XYZ(Eigen::VectorXf f, Eigen::Vector3f r, Eigen::MatrixXf &J_hp_f, Eigen::Matrix3f R) 
{
    const float theta = f(3);
    const float phi = f(4);
    const float ro = f(5);
    Eigen::Vector3f ni;
    ni(0) = std::sin(theta) * std::cos(phi);
    ni(1) = -std::sin(phi);
    ni(2) = std::cos(theta) * std::cos(phi);
    	
    J_hp_f = Eigen::MatrixXf(3,6);
    J_hp_f.middleCols<3>(0) = ro * Eigen::Matrix3f::Identity();

    J_hp_f(0,3) = std::cos(theta) * std::cos(phi);
    J_hp_f(1,3) = 0;
    J_hp_f(2,3) = -std::sin(theta) * std::cos(phi);
    
    J_hp_f(0,4) = -std::sin(theta) * std::sin(phi);
    J_hp_f(1,4) = -std::cos(phi);
    J_hp_f(2,4) = -std::cos(theta) * std::sin(phi);
    
    J_hp_f.col(5) = f.segment<3>(0) - r;
    
    return ro * (f.segment<3>(0) - r) + ni;	
}


Eigen::Vector3f inverse2XYZ(Eigen::VectorXf f, Eigen::Vector3f r) 
{
    const float theta = f(3);
    const float phi = f(4);
    const float ro = f(5);
    
    Eigen::Vector3f ni;
    ni(0) = std::sin(theta) * std::cos(phi);
    ni(1) = -std::sin(phi);
    ni(2) = std::cos(theta) * std::cos(phi);
  
    return ro * (f.segment<3>(0) - r) + ni;
}

 







