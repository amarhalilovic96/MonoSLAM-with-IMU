#include <iostream>

#include <opencv2/opencv.hpp>
#include <opencv2/core.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/core/base.hpp>
#include <opencv2/core/cvstd.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/features2d.hpp>
#include <opencv2/xfeatures2d/nonfree.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/calib3d.hpp>
#include <opencv/cv.h>

#include <opencv2/imgproc/imgproc.hpp>

#include <geometry_msgs/Pose.h>
#include <nav_msgs/Path.h>

#include <visualization_msgs/Marker.h>
#include <visualization_msgs/MarkerArray.h>

#include <eigen3/Eigen/Dense>

#include <Feature.hpp>
#include <Vektori.hpp>
#include <Kamera.hpp>

using namespace Eigen;

class vSLAM
{
   
	public:

        vSLAM();	

	Kamera kamera;	
  	float delta_T;

    	MatrixXf Pn; //Covariance of speed (linear and rotation)
	MatrixXf Kk;
   	MatrixXf Fk;
	MatrixXf Fnt;
    	MatrixXf Hk; // measures prediction
    	VectorXf h_out;
    	VectorXf tot_h_out;

    	MatrixXf Sk; // innovation covariance matrix
    
    
    
    	cv::Mat frame, stari_frame;
    	cv::Mat originalnaSlika;
    	cv::Mat slikaSaZnacajkama;
    
    
    	void nacrtajPredikciju();
    	//void nacrtajKorekciju(cv::Point f);

	float map_scale; // scale of the map

    	std::vector<Feature> features;
    	std::vector<Feature> obrisane_features;

    	VectorXf vektorStanja;
    	MatrixXf Kovarijansa;
	int nFeatures;
    	float T_camera;
	

    	int windowsSize;
    	int sigma_pixel;
    	int sigma_pixel_2;

	int kernel_min_size;
	int scale;
	int sigma_size;

	int nInitFeatures;

	int camera_state_dim;

	float feature_index;

    	int addFeature(cv::Point2f pf);

    	void removeFeature(int index);

    	void predikcija(double v_x, double v_y, double v_z, double w_x, double w_y, double w_z, double delta_T, double max_a, double max_omega);
    	void korekcija();
    
    
   	void primiFrame(cv::Mat newFrame);
    
    	cv::Mat vratiSlikuSaZnacajkama();
    
    	void pronadjiZnacajke();

    	void convert2XYZ(int index);
    	void findFeaturesConvertible2XYZ();
    	Vector3f depth2XYZ(VectorXf f, MatrixXf &J);
	//void updateCameraParameters(double v_x, double v_y, double v_z, double w_x, double w_y, double w_z, double razlika, Eigen::Vector4f orijentacija);



	nav_msgs::Path putanjaKamere;
	void updatePutanje();
	std::vector<Quaternionf> vQuat;
	std::vector<Matrix3f> vCov;
	
	//geometry_msgs::Pose dobijPozicijuKamere();
	visualization_msgs::MarkerArray vratiZnacajke3D();
	visualization_msgs::MarkerArray vratiKameru3D();
	nav_msgs::Path dobijPutanjuKamere();

};

	Vector3f inverse2XYZ(VectorXf f, Vector3f r, MatrixXf &J_hp_f , Matrix3f R = Matrix3f::Identity());
	Vector3f inverse2XYZ(VectorXf f, Vector3f r);	

	MatrixXi computeEllipsoidParameters(MatrixXf St, int sigma_size);

	bool isInsideImage(Vector2f hi, cv::Size size, int windowsSize);
