#include <iostream>
#include <opencv2/opencv.hpp>
#include <eigen3/Eigen/Dense>
#include <stdio.h>
#include <stdlib.h>

using namespace Eigen;

MatrixXf vConcat(MatrixXf m1, MatrixXf m2);
MatrixXf hConcat(MatrixXf m1, MatrixXf m2);
VectorXf Concat(VectorXf m1, VectorXf m2);

Vector4f vektorUKvaternion(Vector3f vec);

Matrix3f kvaternionURotacionuMatricu(Vector4f quat);

Vector4f komplementKvaterniona(Vector4f quat);

Matrix3f diffQuat2rot(Vector4f quat, int index); // compute de partial derivate matrix of q2r(q) for q_index

Vector4f jedinicniKvaternion();
Vector4f proizvodKvaterniona(Vector4f h, Vector4f g);


// return Jacobian d(g(x))/dx
MatrixXf df_dx(VectorXf X_old, float dT);


// compute the Jacobian between q(t) and q(t-1) knowing the rotation h = quat(w*T)
Matrix4f Jacobian_qt_qt1(Vector4f h);

// Computer the Jacobian df/dhW
MatrixXf d_f_d_hW(Vector3f hW);

// compute the Jacobian between q(t) and w(t-1) knowing the actual rotation q, w and dT
MatrixXf Jacobian_qt_w(Vector4f q, Vector3f w, float dT);

// return the Jacobian d(q^c)/d(q)
Matrix4f d_qbar_q();

// return Jacobian d(R(q)d)/dq
MatrixXf dRq_times_d_dq(Vector4f q, Vector3f d);

void normalizujKvaternion(VectorXf &vektorStanja, MatrixXf &Kovarijansa);

Matrix4f kvaternionJacobian(Vector4f q1);

Matrix4f kvaternionJacobianKomplementarni(Vector4f q1);

Eigen::VectorXf updateCameraParameters(VectorXf Xv, double dT, Eigen::Vector3f lin_v, Eigen::Vector3f ug_w);



	
