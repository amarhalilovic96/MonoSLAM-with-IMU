#include <opencv2/opencv.hpp>
#include <eigen3/Eigen/Dense>


using namespace Eigen;

class Kamera 
{

public:
	
    	Kamera();

	float fx, fy, u0, v0, k1, k2, k3, p1, p2;

	float sigma_vx, sigma_vy, sigma_vz;
	float sigma_wx, sigma_wy, sigma_wz;

	float rho_0;
	float sigma_rho_0;

	int window_size;
	int sigma_pixel;
	
	int kernel_size;
	int sigma_size;
	
	int scale;

	float T_camera;

	int nInitFeatures;
	int min_features;
	int max_features;

	int forsePlane;


    	Eigen::Vector3f UndistortAndDeproject(Eigen::Vector2f v, Eigen::MatrixXf &J);
    	Eigen::Vector2f projectAndDistort(Eigen::Vector3f v, Eigen::MatrixXf &J);
	Eigen::Vector2f projectAndDistort(Eigen::Vector3f v);
	Eigen::Matrix2f diff_distort_undistort(Eigen::Vector2f v);

};


